# Prompt Optimizer — Optimizer Agent 스펙

## Context

review-agent가 프롬프트를 루브릭 기반으로 채점하고 항목별 개선안(`improvements`)을 제시하는 단계까지 완성되었다.
optimizer-agent는 이 리뷰 결과를 입력받아, 원본 프롬프트에 개선안을 **자동 반영**한 새 프롬프트를 생성한다.

- **입력**: 원본 프롬프트(`prompts_.st`) + 리뷰 결과(`review_result.json`)
- **출력**: 개선된 프롬프트(`optimized_prompts.st`)
- summary-agent가 외부 시스템이라 re-review 루프는 불가 → **단일 패스**로 개선 프롬프트를 생성한다.

## 입력 파일

| 파일 | 형식 | 설명 |
|------|------|------|
| `prompts_.st` | 평문 텍스트 | summary-agent 시스템 프롬프트 (개선 대상) |
| `review_result.json` | JSON | review-agent가 생성한 채점 결과 (ReviewResult 스키마) |

### review_result.json 구조 (입력으로 사용하는 필드)

```json
{
  "criteria": [
    {
      "name": "core_content_accuracy",
      "score": 25.0,
      "max_score": 30.0,
      "reason": "감점 사유 설명",
      "improvements": ["개선안 1", "개선안 2"]
    }
  ],
  "top_improvements": ["최우선 개선안 1", "최우선 개선안 2", "최우선 개선안 3"],
  "overall_feedback": "전체 평가 피드백"
}
```

optimizer-agent가 참고하는 핵심 필드:
- `top_improvements` — 우선순위 높은 개선안 (전체 수준)
- `criteria[].improvements` — 카테고리별 구체적 개선안
- `criteria[].reason` — 감점 사유 (맥락 이해용)
- `overall_feedback` — 전체 피드백 (방향성 이해용)

## 출력

| 파일 | 형식 | 설명 |
|------|------|------|
| `optimized_prompts.st` | 평문 텍스트 | 개선안이 반영된 새 프롬프트 |

- CLI 모드: `{paths.output_dir}/optimized_prompts.st` (기본: `sample/outputs/optimized_prompts.st`)
- API 모드: FileResponse로 다운로드 반환

## LangGraph 설계

### 상태 (`graph/state.py` — OptimizeState 신규)

```python
class OptimizeState(TypedDict):
    prompt: str                 # 원본 프롬프트 텍스트
    review_result: dict         # 리뷰 결과 JSON (ReviewResult 스키마)
    optimized_prompt: str       # 생성된 개선 프롬프트
    error: str | None
```

기존 `ReviewState`는 변경하지 않는다.

### 그래프 (`graph/optimize_graph.py` — 신규)

```
[optimize] → END
```

review 그래프와 완전히 분리된 별도 그래프.
API 서버가 엔드포인트에 따라 review 그래프 또는 optimize 그래프를 호출한다.

### optimize 노드 동작

1. state에서 `prompt`(원본)와 `review_result`를 읽는다
2. `review_result`에서 개선안을 추출한다:
   - `top_improvements` (전체 우선순위 개선안)
   - `criteria[].improvements` (카테고리별 개선안)
   - `criteria[].reason` (감점 사유 — 맥락 참고)
3. optimizer 시스템 프롬프트에 원본 프롬프트 + 개선안을 주입하여 LLM 호출
4. LLM 응답(개선된 프롬프트 텍스트)을 `optimized_prompt`에 저장
5. `save_to_disk: True`일 때 `{output_dir}/optimized_prompts.st`에 저장

### configurable 구조

```python
graph_config = {
    "configurable": {
        "llm": ChatOpenAI,
        "paths": {"output_dir": "./sample/outputs"},
        "app_config": { ... },
        "save_to_disk": True/False,
    }
}
```

## optimizer 시스템 프롬프트 (`agents/optimizer/prompts/optimizer_system.md`)

```
너는 AI 회의록 요약 프롬프트 개선 전문가다.
아래 리뷰 결과를 분석하여, 원본 프롬프트의 문제점을 개선한 새 프롬프트를 작성하라.

## 개선 원칙
1. 원본 프롬프트의 전체 구조와 의도를 유지한다
2. 리뷰에서 지적된 문제를 해결하는 최소한의 변경만 수행한다
3. 새로운 지시문은 구체적이고 실행 가능해야 한다
4. 기존 지시문과 충돌하는 내용은 기존 것을 수정한다
5. 프롬프트의 언어(영문/한글)는 원본을 따른다

## 리뷰 결과

### 전체 피드백
{overall_feedback}

### 최우선 개선안
{top_improvements}

### 카테고리별 감점 사유 및 개선안
{criteria_details}

## 원본 프롬프트
{prompt}

## 응답 형식
개선된 프롬프트 전문을 그대로 출력하라. JSON이나 마크다운으로 감싸지 마라.
```

## API 엔드포인트

### `POST /optimize`

| 파라미터 | 타입 | 설명 |
|---|---|---|
| `prompt` | `UploadFile` | 원본 summary-agent 시스템 프롬프트 |
| `review_result` | `UploadFile` | review-agent가 생성한 리뷰 결과 JSON |

**요청 예시 (curl):**
```bash
curl -X POST http://localhost:8000/optimize \
  -F "prompt=@sample/inputs/prompts_.st" \
  -F "review_result=@sample/outputs/review_result.json" \
  -o optimized_prompts.st
```

**응답:**
- 성공: `200 OK` + `optimized_prompts.st` FileResponse (Content-Type: text/plain)
- 실패: `500` + `{"detail": "에러 메시지"}`

**API 모드 동작:**
1. 업로드 파일을 UTF-8 문자열로 읽어 `OptimizeState`에 주입
2. review_result 문자열을 `json.loads()`로 파싱하여 dict로 변환
3. optimize 그래프 실행
4. `optimized_prompt` 결과를 임시 파일에 저장 후 FileResponse로 반환

## CLI 실행 (`run_optimize.py`)

```bash
uv run python run_optimize.py --config config.yaml \
  --prompt sample/inputs/prompts_.st \
  --review-result sample/outputs/review_result.json
```

| 인자 | 설명 |
|---|---|
| `--config` | config.yaml 경로 (기본: 환경변수 CONFIG_PATH) |
| `--prompt` | 원본 프롬프트 파일 경로 |
| `--review-result` | 리뷰 결과 JSON 파일 경로 |
| `--output-dir` | 출력 디렉토리 (config의 output_dir 대신 사용) |

결과: `sample/outputs/optimized_prompts.st` 생성

## 프로젝트 구조 (추가분)

```
prompt-optimizer/
├── run_optimize.py                  # CLI 진입점 (optimizer 테스트용)
├── graph/
│   └── optimize_graph.py            # optimize 그래프 정의
├── agents/
│   └── optimizer/
│       ├── __init__.py
│       ├── nodes.py                 # optimize 노드 함수
│       └── prompts/
│           └── optimizer_system.md  # optimizer 시스템 프롬프트
└── api_server.py                    # POST /optimize 엔드포인트 추가
```

## review-agent와의 관계

```
[n8n / CLI]
    │
    ├─ POST /review (또는 run_review.py)
    │     파일 5개 → review_result.json
    │
    └─ POST /optimize (또는 run_optimize.py)
          prompts_.st + review_result.json → optimized_prompts.st
```

- 두 에이전트는 **독립적**으로 동작한다
- review+optimize가 필요하면 n8n에서 `/review` → `/optimize` 순차 호출
- review 없이 optimize만 호출할 수도 있다 (외부에서 생성한 review_result 사용 가능)

## 검증

1. **CLI 테스트**:
   ```bash
   uv run python run_optimize.py \
     --prompt sample/inputs/prompts_.st \
     --review-result sample/outputs/review_result.json
   ```
   → `sample/outputs/optimized_prompts.st` 생성 확인
   → 개선된 프롬프트가 원본 구조를 유지하면서 개선안이 반영되었는지 확인

2. **API 테스트**:
   ```bash
   curl -X POST http://localhost:8000/optimize \
     -F "prompt=@sample/inputs/prompts_.st" \
     -F "review_result=@sample/outputs/review_result.json" \
     -o optimized_prompts.st
   ```
   → `200 OK` + `optimized_prompts.st` 파일 다운로드 확인
