import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from langchain_core.messages import HumanMessage
from langchain_core.runnables import RunnableConfig

from agents.review.context import chunk_script, decide_strategy
from graph.state import ReviewState
from schemas.review_result import ReviewResult

logger = logging.getLogger(__name__)


def load_inputs(state: ReviewState, config: RunnableConfig) -> dict:
    """config.yaml의 paths/files에서 입력 파일들을 로드한다.
    state에 이미 파일 내용이 주입되어 있으면(API 모드) 디스크 로드를 스킵한다.
    """
    if state.get("script") and state.get("summary"):
        logger.info("Inputs already present in state, skipping disk load")
        return {"error": None}

    cfg = config["configurable"]
    input_dir = Path(cfg["paths"]["input_dir"])
    files = cfg["files"]

    logger.info("Loading input files from %s", input_dir)
    try:
        script = (input_dir / files["script"]).read_text(encoding="utf-8")
        summary = (input_dir / files["summary"]).read_text(encoding="utf-8")
        prompt = (input_dir / files["prompt"]).read_text(encoding="utf-8")
        rubric = (input_dir / files["rubric"]).read_text(encoding="utf-8")
    except FileNotFoundError as e:
        logger.error("Input file not found: %s", e)
        return {"error": f"입력 파일을 찾을 수 없습니다: {e}"}

    logger.info("Input files loaded (script=%d chars, summary=%d chars)", len(script), len(summary))
    return {
        "script": script,
        "summary": summary,
        "prompt": prompt,
        "rubric": rubric,
        "error": None,
    }


def check_context(state: ReviewState, config: RunnableConfig) -> dict:
    """토큰 추정 후 컨텍스트 전략을 결정한다."""
    if state.get("error"):
        return {}

    app_config = config["configurable"]["app_config"]
    strategy = decide_strategy(
        state["script"],
        state["summary"],
        state["prompt"],
        state["rubric"],
        app_config,
    )

    logger.info("Context strategy resolved: %s", strategy)
    result = {"context_strategy": strategy, "script_chunks": []}

    if strategy == "chunked":
        result["script_chunks"] = chunk_script(state["script"], app_config)
        logger.info("Script split into %d chunks", len(result["script_chunks"]))

    return result


def _build_review_prompt(
    rubric: str,
    prompt: str,
    summary: str,
    script: str,
) -> str:
    """리뷰 시스템 프롬프트를 조립한다."""
    prompts_dir = Path(__file__).parent / "prompts"
    template = (prompts_dir / "review_system.md").read_text(encoding="utf-8")
    output_schema = (prompts_dir / "output_schema.json").read_text(encoding="utf-8")
    return template.format(
        rubric=rubric,
        prompt=prompt,
        summary=summary,
        script=script,
        output_schema=output_schema,
    )


def review(state: ReviewState, config: RunnableConfig) -> dict:
    """full 또는 no_script 전략으로 LLM을 호출한다."""
    if state.get("error"):
        return {}

    llm = config["configurable"]["llm"]
    strategy = state["context_strategy"]

    script_content = state["script"] if strategy == "full" else "(컨텍스트 한도 초과로 생략됨)"

    content = _build_review_prompt(
        state["rubric"],
        state["prompt"],
        state["summary"],
        script_content,
    )

    logger.info("LLM call started (strategy: %s)", strategy)
    response = llm.invoke([HumanMessage(content=content)])
    logger.info("LLM response received (%d chars)", len(response.content))
    return {"review_result": {"raw_response": response.content}}


def chunked_review(state: ReviewState, config: RunnableConfig) -> dict:
    """script를 청크별로 나눠 각각 LLM을 호출한다."""
    if state.get("error"):
        return {}

    llm = config["configurable"]["llm"]
    chunks = state["script_chunks"]
    chunk_results = []

    logger.info("Chunked review started (%d chunks)", len(chunks))
    for i, chunk in enumerate(chunks):
        content = _build_review_prompt(
            state["rubric"],
            state["prompt"],
            state["summary"],
            f"(청크 {i + 1}/{len(chunks)})\n{chunk}",
        )
        logger.info("Chunk %d/%d LLM call", i + 1, len(chunks))
        response = llm.invoke([HumanMessage(content=content)])
        logger.info("Chunk %d/%d response received (%d chars)", i + 1, len(chunks), len(response.content))
        chunk_results.append(response.content)

    logger.info("Chunked review completed")
    return {"review_result": {"chunk_responses": chunk_results}}


def aggregate(state: ReviewState, config: RunnableConfig) -> dict:
    """청크별 결과를 집계하여 최종 점수를 산출한다."""
    if state.get("error"):
        return {}

    llm = config["configurable"]["llm"]
    chunk_responses = state["review_result"].get("chunk_responses", [])

    aggregate_prompt = (
        "아래는 동일한 프롬프트에 대해 원본 데이터를 여러 청크로 나눠 평가한 결과들이다.\n"
        "이 결과들을 종합하여 하나의 최종 평가를 JSON 형식으로 작성하라.\n"
        "각 항목의 점수는 청크별 점수의 평균으로 산출하되, 근거와 개선안은 통합하라.\n\n"
    )
    for i, resp in enumerate(chunk_responses):
        aggregate_prompt += f"--- 청크 {i + 1} 결과 ---\n{resp}\n\n"

    logger.info("Aggregation LLM call (%d chunks)", len(chunk_responses))
    response = llm.invoke([HumanMessage(content=aggregate_prompt)])
    logger.info("Aggregation response received (%d chars)", len(response.content))
    return {"review_result": {"raw_response": response.content}}


def parse_output(state: ReviewState, config: RunnableConfig) -> dict:
    """LLM 응답을 Pydantic 스키마로 파싱하고 JSON 파일로 저장한다."""
    if state.get("error"):
        return {}

    raw = state["review_result"].get("raw_response", "")
    logger.info("Parsing LLM response (%d chars)", len(raw))

    # JSON 블록 추출
    json_str = raw
    if "```json" in raw:
        json_str = raw.split("```json")[1].split("```")[0].strip()
    elif "```" in raw:
        json_str = raw.split("```")[1].split("```")[0].strip()

    try:
        parsed = json.loads(json_str)
    except json.JSONDecodeError as e:
        logger.error("JSON parse failed: %s", e)
        return {"error": f"JSON 파싱 실패: {e}\n원본 응답:\n{raw}"}

    cfg = config["configurable"]
    parsed["metadata"] = {
        "model": cfg["app_config"]["llm"]["provider"],
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "context_strategy": state["context_strategy"],
        "score_version": cfg.get("score_version", "v1"),
        "prompt_version": cfg.get("prompt_version", "v1"),
    }

    try:
        result = ReviewResult(**parsed)
    except Exception as e:
        logger.error("Schema validation failed: %s", e)
        return {"error": f"스키마 검증 실패: {e}"}

    result_json = result.model_dump_json(indent=2, ensure_ascii=False)
    logger.debug("Review result:\n%s", result_json)

    # 항상 디스크에 저장
    output_dir = Path(cfg["paths"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    score_version = cfg.get("score_version", "v1")
    prompt_version = cfg.get("prompt_version", "v1")
    filename = f"review_result_{score_version}_{prompt_version}.json"

    output_path = output_dir / filename
    output_path.write_text(result_json, encoding="utf-8")
    logger.info("Review result saved: %s (total_score: %s)", output_path, result.total_score)

    return {"review_result": result.model_dump()}


def route_after_context(state: ReviewState) -> str:
    """check_context 이후 분기를 결정한다."""
    if state.get("error"):
        return "parse_output"
    if state["context_strategy"] == "chunked":
        return "chunked_review"
    return "review"
