from typing import TypedDict


class ReviewState(TypedDict):
    # 입력
    script: str
    summary: str
    prompt: str
    rubric: str
    # 컨텍스트 관리
    context_strategy: str       # "full" | "no_script" | "chunked"
    script_chunks: list[str]
    # 출력
    review_result: dict
    error: str | None


class OptimizeState(TypedDict):
    prompt: str                 # 원본 프롬프트 텍스트
    review_result: dict         # 리뷰 결과 JSON (ReviewResult 스키마)
    optimized_prompt: str       # 생성된 개선 프롬프트
    error: str | None
