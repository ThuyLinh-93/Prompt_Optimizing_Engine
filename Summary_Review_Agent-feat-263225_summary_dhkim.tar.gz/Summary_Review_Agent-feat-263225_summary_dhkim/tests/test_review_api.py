"""POST /review API 테스트 — Form 필드 + JSON 응답 검증."""

import io
import json
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient


def _mock_config():
    return {
        "llm": {
            "provider": "vllm",
            "vllm": {"base_url": "http://localhost:8080/v1", "model": "gemma"},
            "openai": {"model": "gpt-4o"},
            "temperature": 0.3,
            "max_tokens": 4096,
        },
        "langsmith": {"enabled": False, "project": "test"},
        "server": {"host": "0.0.0.0", "port": 8080},
        "files": {},
        "paths": {"input_dir": "/tmp/inputs", "output_dir": "/tmp/outputs"},
        "context": {"max_input_tokens": 32000, "strategy": "auto", "chunk_size": 2000},
    }


def _review_result_dict():
    return {
        "total_score": 85.0,
        "max_total_score": 100.0,
        "criteria": [],
        "overall_feedback": "good",
        "top_improvements": [],
        "metadata": {},
    }


@pytest.fixture
def client():
    with (
        patch("api_server._load_config", return_value=_mock_config()),
        patch("api_server.setup_langsmith"),
        patch("api_server.get_llm", return_value=MagicMock()),
        patch("api_server.build_review_graph") as mock_graph_builder,
    ):
        mock_graph = MagicMock()
        mock_graph.invoke.return_value = {
            "review_result": _review_result_dict(),
            "error": None,
        }
        mock_graph_builder.return_value = mock_graph

        from api_server import app

        yield TestClient(app)


def _upload_files(score_version="v1", prompt_version="v1"):
    return {
        "script": ("script.json", io.BytesIO(b'{"text":"hello"}'), "application/json"),
        "summary": ("summary.json", io.BytesIO(b'{"text":"sum"}'), "application/json"),
        "prompt": ("prompt.txt", io.BytesIO(b"prompt content"), "text/plain"),
        "rubric": ("rubric.md", io.BytesIO(b"# rubric"), "text/markdown"),
    }


class TestReviewEndpoint:
    def test_returns_json_with_total_score(self, client):
        resp = client.post(
            "/review",
            files=_upload_files(),
            data={"score_version": "v1", "prompt_version": "v1"},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert "total_score" in body
        assert "result_file_path" in body
        assert body["total_score"] == 85.0
        assert "input_files" in body
        assert body["input_files"]["script"] == "script.json"
        assert body["input_files"]["summary"] == "summary.json"
        assert body["input_files"]["prompt"] == "prompt.txt"
        assert body["input_files"]["rubric"] == "rubric.md"

    def test_default_versions(self, client):
        """score_version, prompt_version 미전송 시 기본값 v1."""
        resp = client.post("/review", files=_upload_files())
        assert resp.status_code == 200
        body = resp.json()
        assert "review_result_v1_v1.json" in body["result_file_path"]

    def test_custom_versions_in_path(self, client):
        resp = client.post(
            "/review",
            files=_upload_files(),
            data={"score_version": "v2", "prompt_version": "v3"},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert "review_result_v2_v3.json" in body["result_file_path"]

    def test_result_file_path_is_absolute(self, client):
        resp = client.post("/review", files=_upload_files())
        body = resp.json()
        assert body["result_file_path"].startswith("/")

    def test_error_returns_500(self, client):
        with patch("api_server.build_review_graph") as mock_builder:
            mock_graph = MagicMock()
            mock_graph.invoke.return_value = {"error": "something went wrong", "review_result": {}}
            mock_builder.return_value = mock_graph

            resp = client.post("/review", files=_upload_files())
            assert resp.status_code == 500
