# Prompt Optimizer — Review Agent v2 스펙

## Context

프롬프트 옵티마이저 시스템의 **review-agent v2**.
summary-agent가 `scripts_.json`(STT 원문) + `prompts_.st`(시스템 프롬프트)을 받아 `summary_.json`(요약 결과)을 생성하는 파이프라인이 이미 존재한다.
review-agent는 이 요약 결과가 얼마나 잘 되었는지 루브릭 기준으로 평가하고, 프롬프트 개선안을 제시한다.

### v1 → v2 주요 변경

- **template_schema 입력 제거** — 입력 5개 → 4개 (script, summary, prompt, rubric)
- **메타데이터 수신** — `metadata` JSON 파일로 `score_version`, `prompt_version` 수신
- **결과 파일 네이밍** — `review_result_{score_version}_{prompt_version}.json`
- **API 디스크 저장** — API 모드에서도 output_dir에 저장 + FileResponse 반환
- **Docker 배포** — `network_mode: host`, 포트 8085, 볼륨 마운트

**LLM**: vLLM 서버 (`10.1.100.61:8080`) / `gaunernst/gemma-3-27b-it-int4-awq`
**프레임워크**: LangChain + LangGraph + LangSmith (트레이싱/모니터링)
**API 서버**: FastAPI (n8n 연동용)
**패키지 매니저**: uv
**Python**: 3.13

## 프로젝트 구조

```
prompt-optimizer/
├── config.yaml                  # LLM 엔드포인트, 경로, 서버, 컨텍스트 설정
├── langgraph.json               # LangGraph Studio 설정
├── pyproject.toml               # 프로젝트 의존성 (uv)
├── .python-version              # Python 3.13 고정
├── Dockerfile                   # Docker 이미지 빌드
├── docker-compose.yml           # Docker Compose 배포
├── .dockerignore
├── api_server.py                # FastAPI 서버 (n8n 연동용, POST /review, POST /optimize)
├── run_review.py                # CLI 진입점 (테스트용)
├── settings.py                  # 환경변수 설정 (pydantic-settings)
├── graph/
│   ├── __init__.py
│   ├── state.py                 # LangGraph 상태 정의 (TypedDict)
│   ├── review_graph.py          # 리뷰 그래프 정의
│   └── optimize_graph.py        # 최적화 그래프 정의
├── agents/
│   └── review/
│       ├── __init__.py
│       ├── nodes.py             # 그래프 노드 함수들
│       ├── context.py           # 컨텍스트 크기 관리 (청킹/트리밍)
│       └── prompts/
│           ├── review_system.md # 리뷰어 시스템 프롬프트
│           └── output_schema.json # LLM 응답 JSON 형식 정의
├── models/
│   ├── __init__.py
│   └── llm_client.py           # LangChain ChatOpenAI 클라이언트 (vLLM/OpenAI)
├── schemas/
│   ├── __init__.py
│   └── review_result.py        # 출력 JSON 스키마 (Pydantic)
├── sample/
│   ├── inputs/                  # 테스트용 샘플 파일
│   │   ├── scripts_.json
│   │   ├── summary_.json
│   │   ├── prompts_.st
│   │   └── score_.json
│   └── outputs/                 # CLI 테스트 결과 저장
├── docs/
│   ├── SPEC.md                  # v1 스펙 (보존)
│   ├── SPEC_v2.md               # v2 스펙 (본 문서)
│   ├── decisions.md
│   └── langgraph-studio-setup.md
├── .env                         # LANGSMITH_API_KEY 등 시크릿
└── .env.example                 # .env 템플릿
```

## 실행 모드

### 1. API 서버 (n8n 연동)

n8n에서 multipart/form-data로 파일 4개 + 메타데이터를 업로드하면, 리뷰 결과를 디스크에 저장하고 FileResponse로 반환한다.

```bash
# 로컬 기동
uv run uvicorn api_server:app --host 0.0.0.0 --port 8080

# Docker 기동
docker compose up -d
```

**엔드포인트: `POST /review`**

| 파라미터 | 타입 | 설명 |
|---|---|---|
| `script` | `UploadFile` | STT 원문 JSON |
| `summary` | `UploadFile` | 요약 결과 JSON |
| `prompt` | `UploadFile` | summary-agent 시스템 프롬프트 |
| `rubric` | `UploadFile` | 평가 루브릭 JSON |
| `metadata` | `UploadFile` | 메타데이터 JSON (`{"score_version": "v1", "prompt_version": "v1"}`) |

**요청 예시 (curl):**
```bash
curl -X POST http://localhost:8085/review \
  -F "script=@sample/inputs/scripts_.json" \
  -F "summary=@sample/inputs/summary_.json" \
  -F "prompt=@sample/inputs/prompts_.st" \
  -F "rubric=@sample/inputs/score_.json" \
  -F "metadata=@metadata.json" \
  -o review_result_v1_v1.json
```

**응답:**
- 성공: `200 OK` + `review_result_{score_version}_{prompt_version}.json` FileResponse
- 실패: `500` + `{"detail": "에러 메시지"}`

**API 모드 동작:**
1. 업로드 파일을 UTF-8 문자열로 읽어 `initial_state`에 직접 주입
2. `load_inputs` 노드는 state에 값이 있으면 디스크 로드 스킵
3. `parse_output` 노드가 output_dir에 결과 파일 저장
4. 저장된 파일을 FileResponse로 반환

### 2. CLI (테스트용)

`sample/inputs`의 파일을 읽어 `./outputs`에 결과를 저장한다.

```bash
uv run python run_review.py --config config.yaml
```

결과 파일: `./outputs/review_result_v1_v1.json`

### 3. Docker 배포

```bash
docker compose up -d
```

| 항목 | 값 |
|---|---|
| 네트워크 모드 | `host` (vLLM 내부망 접근용) |
| 서비스 포트 | 8085 |
| 출력 볼륨 | `/DATA/WEB/storage/prompt/review` → `/app/outputs` |
| 환경변수 | `.env` 파일 마운트 |

## 입력 파일

| 파일 | 설명 |
|---|---|
| `scripts_.json` | STT 원문 (stt 배열: blockid, speakerName, content, index) |
| `summary_.json` | 요약 결과 (mainKeywords, mainTasks, meetingContent, upcomingSchedule) |
| `prompts_.st` | summary-agent 시스템 프롬프트 (평문 텍스트) |
| `score_.json` | 평가 루브릭 (100점 감점 기반, 5개 카테고리 + hard_cap_rules) |

## LangGraph 설계

### 상태 (`graph/state.py`)

```python
class ReviewState(TypedDict):
    # 입력
    script: str              # scripts_.json 원문
    summary: str             # summary_.json 원문
    prompt: str              # prompts_.st 원문
    rubric: str              # score_.json 원문
    # 컨텍스트 관리
    context_strategy: str    # "full" | "no_script" | "chunked"
    script_chunks: list[str] # 청킹된 script (chunked 전략 시)
    # 출력
    review_result: dict      # 최종 리뷰 결과 JSON
    error: str | None        # 에러 메시지
```

### 그래프 흐름

```
[load_inputs] → [check_context] → [review] → [parse_output] → END
                       ↓ (chunked)
                 [chunked_review] → [aggregate] → [parse_output] → END
```

**노드 설명:**
1. **load_inputs** — state에 값이 없으면 디스크에서 파일 4개 로드 (API 모드에서는 스킵)
2. **check_context** — 전체 토큰 추정 → 전략 결정 (full / no_script / chunked)
3. **review** — LLM 호출 (full 또는 no_script 전략)
4. **chunked_review** — script를 청크별로 나눠 각각 LLM 호출
5. **aggregate** — 청크별 결과를 집계하여 최종 점수 산출
6. **parse_output** — LLM 응답을 Pydantic 스키마로 파싱 + 항상 디스크에 저장

### 결과 파일 네이밍

`review_result_{score_version}_{prompt_version}.json`

- `score_version`: 채점 루브릭 버전 (API Form 필드 또는 기본값 "v1")
- `prompt_version`: 프롬프트 버전 (API Form 필드 또는 기본값 "v1")

버전 정보는 `config["configurable"]`에서 읽는다.

### 결과 JSON metadata

`parse_output` 노드가 결과 JSON에 `metadata` 필드를 자동 추가한다.

```json
{
  "metadata": {
    "model": "vllm",
    "timestamp": "2026-03-04T08:35:07.140863+00:00",
    "context_strategy": "full",
    "score_version": "v1",
    "prompt_version": "v1"
  }
}
```

| 필드 | 설명 |
|---|---|
| `model` | `config.yaml`의 `llm.provider` ("vllm" \| "openai") |
| `timestamp` | UTC ISO 8601 |
| `context_strategy` | "full" \| "no_script" \| "chunked" |
| `score_version` | 채점 루브릭 버전 |
| `prompt_version` | 프롬프트 버전 |

### `configurable` 구조

```python
graph_config = {
    "configurable": {
        "llm": ChatOpenAI,          # LLM 클라이언트 인스턴스
        "paths": {
            "input_dir": "./sample/inputs",
            "output_dir": "./outputs",
        },
        "files": {                   # CLI 모드에서 파일명 매핑
            "script": "scripts_.json",
            "summary": "summary_.json",
            "prompt": "prompts_.st",
            "rubric": "score_.json",
        },
        "app_config": { ... },       # config.yaml 전체
        "score_version": "v1",       # 채점 루브릭 버전
        "prompt_version": "v1",      # 프롬프트 버전
    }
}
```

## 환경변수 설정 (`settings.py`)

pydantic-settings 기반으로 환경변수를 중앙 관리한다.

```python
class Settings(BaseSettings):
    config_path: str = "config.yaml"
    log_level: str = "INFO"
    langsmith_api_key: str = ""
    openai_api_key: str = ""
```

## config.yaml

```yaml
llm:
  provider: "vllm"
  vllm:
    base_url: "http://10.1.100.61:8080/v1"
    model: "gaunernst/gemma-3-27b-it-int4-awq"
  openai:
    model: "gpt-4o"
  temperature: 0.3
  max_tokens: 4096

langsmith:
  enabled: true
  project: "prompt-optimizer"

paths:
  input_dir: "./sample/inputs"
  output_dir: "./outputs"

server:
  host: "0.0.0.0"
  port: 8080

files:
  script: "scripts_.json"
  summary: "summary_.json"
  prompt: "prompts_.st"
  rubric: "score_.json"

context:
  max_input_tokens: 32000
  strategy: "auto"
  chunk_size: 2000
```

## 리뷰 프롬프트 (`review_system.md`)

```
너는 AI 회의록 요약 프롬프트 품질 평가자다.
아래 평가 루브릭에 따라, 주어진 프롬프트가 STT 원문을 요약한 결과를 평가하라.

평가 시 다음을 확인하라:
1. 요약 결과가 STT 원문의 핵심 내용을 정확히 반영하는가
2. 루브릭의 각 카테고리별 감점 기준에 해당하는 문제가 있는가
3. hard_cap_rules에 해당하는 심각한 문제(환각, 결정사항 왜곡)가 있는가

## 평가 루브릭
{rubric}

## 평가 대상 프롬프트
{prompt}

## 프롬프트가 생성한 요약 결과
{summary}

## 원본 STT 데이터
{script}

## 응답 형식
{output_schema}
```

## 검증 방법

### CLI
```bash
uv run python run_review.py --config config.yaml
# → ./outputs/review_result_v1_v1.json 생성 확인
```

### API
```bash
uv run uvicorn api_server:app --host 0.0.0.0 --port 8080

curl -X POST http://localhost:8080/review \
  -F "script=@sample/inputs/scripts_.json" \
  -F "summary=@sample/inputs/summary_.json" \
  -F "prompt=@sample/inputs/prompts_.st" \
  -F "rubric=@sample/inputs/score_.json" \
  -F "metadata=@metadata.json" \
  -o review_result_v1_v1.json
# → 200 OK + FileResponse + output_dir에도 저장 확인
```

### Docker
```bash
docker compose up -d

curl -X POST http://localhost:8085/review \
  -F "script=@sample/inputs/scripts_.json" \
  -F "summary=@sample/inputs/summary_.json" \
  -F "prompt=@sample/inputs/prompts_.st" \
  -F "rubric=@sample/inputs/score_.json" \
  -F "metadata=@metadata.json" \
  -o review_result_v1_v1.json
# → /DATA/WEB/storage/prompt/review/review_result_v1_v1.json 생성 확인
```
