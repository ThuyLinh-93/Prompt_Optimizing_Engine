# Prompt Optimizer — Review Agent 스펙

## Context

프롬프트 옵티마이저 시스템의 첫 번째 단계로 **review-agent**를 구현한다.
summary-agent가 `scripts_.json`(STT 원문) + `prompts_.st`(시스템 프롬프트, 평문 텍스트)을 받아 `summary_.json`(요약 결과)을 생성하는 파이프라인이 이미 존재한다.
review-agent는 이 요약 결과가 얼마나 잘 되었는지 루브릭 기준으로 평가하고, 프롬프트 개선안을 제시한다.

**LLM**: vLLM 서버 (`10.1.100.61:8080`) / `gaunernst/gemma-3-27b-it-int4-awq`
**프레임워크**: LangChain + LangGraph + LangSmith (트레이싱/모니터링)
**API 서버**: FastAPI (n8n 연동용)
**패키지 매니저**: uv
**Python**: 3.13 (3.14는 langgraph-api 의존성 미지원)

## 프로젝트 구조

```
prompt-optimizer/
├── config.yaml                  # LLM 엔드포인트, 경로, 서버, 컨텍스트 설정
├── langgraph.json               # LangGraph Studio 설정
├── pyproject.toml               # 프로젝트 의존성 (uv)
├── .python-version              # Python 3.13 고정
├── api_server.py                # FastAPI 서버 (n8n 연동용, POST /review)
├── run_review.py                # CLI 진입점 (테스트용)
├── settings.py                  # 환경변수 설정 (pydantic-settings)
├── graph/
│   ├── __init__.py
│   ├── state.py                 # LangGraph 상태 정의 (TypedDict)
│   └── review_graph.py          # 리뷰 그래프 정의 (노드 + 엣지) + Studio용 모듈 레벨 변수
├── agents/
│   └── review/
│       ├── __init__.py
│       ├── nodes.py             # 그래프 노드 함수들 (load, check_context, review, parse)
│       ├── context.py           # 컨텍스트 크기 관리 (청킹/트리밍)
│       └── prompts/
│           ├── review_system.md # 리뷰어 시스템 프롬프트
│           └── output_schema.json # LLM 응답 JSON 형식 정의
├── models/
│   ├── __init__.py
│   └── llm_client.py           # LangChain ChatOpenAI 클라이언트 (vLLM/OpenAI)
├── schemas/
│   ├── __init__.py
│   └── review_result.py        # 출력 JSON 스키마 (Pydantic)
├── sample/
│   ├── inputs/                  # 테스트용 샘플 파일
│   │   ├── scripts_.json
│   │   ├── summary_.json
│   │   ├── prompts_.st
│   │   ├── score_.json
│   │   └── template_schema_.json
│   └── outputs/                 # CLI 테스트 결과 저장
├── docs/
│   ├── SPEC.md
│   ├── decisions.md
│   └── langgraph-studio-setup.md
├── .env                         # LANGSMITH_API_KEY 등 시크릿
└── .env.example                 # .env 템플릿
```

## 실행 모드

### 1. API 서버 (n8n 연동)

n8n에서 multipart/form-data로 파일 5개를 업로드하면, 리뷰 결과를 JSON 파일로 다운로드 응답(FileResponse)한다.

```bash
# 서버 기동
uv run uvicorn api_server:app --host 0.0.0.0 --port 8000
```

**엔드포인트: `POST /review`**

| 파라미터 | 타입 | 설명 |
|---|---|---|
| `script` | `UploadFile` | STT 원문 JSON |
| `summary` | `UploadFile` | 요약 결과 JSON |
| `prompt` | `UploadFile` | summary-agent 시스템 프롬프트 |
| `rubric` | `UploadFile` | 평가 루브릭 JSON |
| `template_schema` | `UploadFile` | 요약 출력 스키마 JSON |

**요청 예시 (curl):**
```bash
curl -X POST http://localhost:8000/review \
  -F "script=@scripts_.json" \
  -F "summary=@summary_.json" \
  -F "prompt=@prompts_.st" \
  -F "rubric=@score_.json" \
  -F "template_schema=@template_schema_.json" \
  -o review_result.json
```

**응답:**
- 성공: `200 OK` + `review_result.json` FileResponse (Content-Type: application/json)
- 실패: `500` + `{"detail": "에러 메시지"}`

**API 모드 동작:**
1. 업로드 파일을 UTF-8 문자열로 읽어 `initial_state`에 직접 주입
2. `load_inputs` 노드는 state에 값이 있으면 디스크 로드 스킵
3. `parse_output` 노드는 디스크 저장 안 함 (`save_to_disk: False`)
4. 리뷰 결과 JSON을 debug 로그로 출력
5. 임시 파일에 결과 저장 후 FileResponse로 반환

### 2. CLI (테스트용)

`sample/inputs`의 파일을 읽어 `sample/outputs`에 결과를 저장한다.

```bash
uv run python run_review.py --config config.yaml
```

CLI 모드에서는 `load_inputs`가 디스크에서 파일을 로드하고, `parse_output`이 `sample/outputs/review_result.json`에 저장한다.

## 입력 파일

| 파일 | 설명 |
|---|---|
| `scripts_.json` | STT 원문 (stt 배열: blockid, speakerName, content, index) |
| `summary_.json` | 요약 결과 (mainKeywords, mainTasks, meetingContent, upcomingSchedule) |
| `prompts_.st` | summary-agent 시스템 프롬프트 (평문 텍스트) |
| `score_.json` | 평가 루브릭 (100점 감점 기반, 5개 카테고리 + hard_cap_rules) |
| `template_schema_.json` | 요약 출력 스키마 정의 — 빈 구조체를 함께 전달하여 "정해진 구조체 채우기 정확도"를 채점 요소로 사용 |

## LangGraph 설계

### 상태 (`graph/state.py`)

```python
class ReviewState(TypedDict):
    # 입력
    script: str              # scripts_.json 원문
    summary: str             # summary_.json 원문
    prompt: str              # prompts_.st 원문
    rubric: str              # score_.json 원문
    template_schema: str     # template_schema_.json 원문
    # 컨텍스트 관리
    context_strategy: str    # "full" | "no_script" | "chunked"
    script_chunks: list[str] # 청킹된 script (chunked 전략 시)
    # 출력
    review_result: dict      # 최종 리뷰 결과 JSON
    error: str | None        # 에러 메시지
```

### 그래프 흐름

```
[load_inputs] → [check_context] → [review] → [parse_output] → END
                       ↓ (chunked)
                 [chunked_review] → [aggregate] → [parse_output] → END
```

**노드 설명:**
1. **load_inputs** — state에 값이 없으면 디스크에서 파일 5개 로드 (API 모드에서는 스킵)
2. **check_context** — 전체 토큰 추정 → 전략 결정 (full / no_script / chunked)
3. **review** — LLM 호출 (full 또는 no_script 전략)
4. **chunked_review** — script를 청크별로 나눠 각각 LLM 호출
5. **aggregate** — 청크별 결과를 집계하여 최종 점수 산출
6. **parse_output** — LLM 응답을 Pydantic 스키마로 파싱 + debug 로그 출력 + `save_to_disk: True`일 때만 파일 저장

**조건부 엣지:**
- `check_context` → strategy가 "chunked"이면 `chunked_review`, 아니면 `review`
- error 발생 시 → `parse_output`으로 직행

### `configurable` 구조

그래프 실행 시 `RunnableConfig`에 전달되는 설정:

```python
graph_config = {
    "configurable": {
        "llm": ChatOpenAI,          # LLM 클라이언트 인스턴스
        "paths": {
            "input_dir": "./sample/inputs",
            "output_dir": "./sample/outputs",
        },
        "files": {                   # CLI 모드에서 파일명 매핑
            "script": "scripts_.json",
            "summary": "summary_.json",
            "prompt": "prompts_.st",
            "rubric": "score_.json",
            "template_schema": "template_schema_.json",
        },
        "app_config": { ... },       # config.yaml 전체
        "save_to_disk": True/False,  # CLI=True, API=False
    }
}
```

### 확장 포인트

추후 optimizer-agent 추가 시:
```
[review] → [optimize] → [re-review] → (점수 향상 시 END, 아니면 [optimize]으로 루프)
```

## 환경변수 설정 (`settings.py`)

pydantic-settings 기반으로 환경변수를 중앙 관리한다. `.env` 파일을 자동 로드하며, 환경변수로 오버라이드 가능.
소스 수정 없이 `.env` 변경 후 서버 재시작만으로 반영된다.

```python
class Settings(BaseSettings):
    config_path: str = "config.yaml"   # config.yaml 경로 (운영: 절대경로 권장)
    log_level: str = "INFO"            # 로그 레벨 (DEBUG / INFO / WARNING / ERROR)
    langsmith_api_key: str = ""        # LangSmith API Key
    openai_api_key: str = ""           # OpenAI API Key (openai provider 사용 시)
```

**`.env.example`:**
```env
LANGSMITH_API_KEY=your_langsmith_api_key_here
OPENAI_API_KEY=your_openai_api_key_here

# CONFIG_PATH: 상대/절대경로 모두 가능. 운영 서버에서는 절대경로 권장
#   예) /etc/prompt-optimizer/config.yaml
CONFIG_PATH=config.yaml
LOG_LEVEL=INFO
```

**환경변수 오버라이드 예시:**
```bash
LOG_LEVEL=DEBUG CONFIG_PATH=/etc/prompt-optimizer/config.yaml uv run uvicorn api_server:app
```

## 핵심 모듈

### `api_server.py`
- FastAPI 앱. `POST /review` 엔드포인트
- multipart/form-data로 파일 5개 수신 → UTF-8 문자열로 읽기
- `initial_state`에 파일 내용 직접 주입 → 그래프 실행
- `save_to_disk: False`로 설정하여 디스크 저장 없음
- 결과를 임시 파일에 저장 후 `FileResponse`로 반환

### `models/llm_client.py`
- `config.yaml`의 `llm.provider` 값에 따라 클라이언트 생성:
  - `"vllm"` → `ChatOpenAI(base_url=vllm.base_url, model=vllm.model)`
  - `"openai"` → `ChatOpenAI(model=openai.model)` (OPENAI_API_KEY는 .env)
- `get_llm(config)` 팩토리 함수로 provider 스위칭

### `agents/review/context.py`
**3단계 fallback:**
1. **full** — 모든 입력이 컨텍스트 한도 내 → 그대로 전달
2. **no_script** — summary + prompt + rubric만 전달
3. **chunked** — script를 주제/시간 단위 분할 → 각 청크별 부분 평가 → 집계

토큰 추정: 글자 수 기반 (한글 1자 ≈ 2토큰, 영문 1단어 ≈ 1.3토큰)

### `agents/review/prompts/`
- **`review_system.md`** — 리뷰 시스템 프롬프트 템플릿. Python `.format()`으로 변수 주입 (`{rubric}`, `{template_schema}`, `{prompt}`, `{summary}`, `{script}`, `{output_schema}`)
- **`output_schema.json`** — LLM 응답 JSON 형식 정의. `.format()`과 분리되어 이스케이프 없이 관리

### `schemas/review_result.py`

```python
class CriterionResult(BaseModel):
    name: str               # 루브릭 항목명
    score: float            # 획득 점수
    max_score: float        # 만점
    reason: str             # 점수 근거
    improvements: list[str] # 개선 제안

class ReviewResult(BaseModel):
    total_score: float
    max_total_score: float
    criteria: list[CriterionResult]
    overall_feedback: str
    top_improvements: list[str]  # 우선순위 높은 개선안 3-5개
    metadata: dict               # model, timestamp, context_strategy 등
```

## config.yaml

```yaml
llm:
  provider: "vllm"               # "vllm" | "openai" — config로 스위칭
  vllm:
    base_url: "http://10.1.100.61:8080/v1"
    model: "gaunernst/gemma-3-27b-it-int4-awq"
  openai:
    model: "gpt-4o"
  temperature: 0.3
  max_tokens: 4096

langsmith:
  enabled: true
  project: "prompt-optimizer"

paths:
  input_dir: "./sample/inputs"   # CLI 테스트용 경로
  output_dir: "./sample/outputs"

server:
  host: "0.0.0.0"
  port: 8000

files:
  script: "scripts_.json"
  summary: "summary_.json"
  prompt: "prompts_.st"
  rubric: "score_.json"
  template_schema: "template_schema_.json"

context:
  max_input_tokens: 32000
  strategy: "auto"               # auto | full | no_script | chunked
  chunk_size: 2000
```

## 리뷰 프롬프트 (`review_system.md`)

```
너는 AI 회의록 요약 프롬프트 품질 평가자다.
아래 평가 루브릭에 따라, 주어진 프롬프트가 STT 원문을 요약한 결과를 평가하라.

평가 시 다음을 확인하라:
1. 요약 결과가 STT 원문의 핵심 내용을 정확히 반영하는가
2. 요약 결과가 출력 스키마(template_schema)를 올바르게 충족하는가
3. 루브릭의 각 카테고리별 감점 기준에 해당하는 문제가 있는가
4. hard_cap_rules에 해당하는 심각한 문제(환각, 결정사항 왜곡)가 있는가

## 평가 루브릭 (감점 기반, 100점 만점)
{rubric}

## 출력 스키마 정의
{template_schema}

## 평가 대상 프롬프트
{prompt}

## 프롬프트가 생성한 요약 결과
{summary}

## 원본 STT 데이터
{script}

## 응답 형식
반드시 아래 JSON 형식으로만 응답하라.
{output_schema}
```

`{output_schema}`는 `output_schema.json`에서 별도 로드되어 주입된다. 이 분리로 `.format()` 이스케이프(`{{`, `}}`) 없이 JSON 형식을 관리할 수 있다.

## LangGraph Studio

`langgraph dev`로 로컬 개발 서버를 띄우면 Studio UI에서 그래프 시각화·디버깅이 가능하다.
상세 설정은 [langgraph-studio-setup.md](./langgraph-studio-setup.md) 참고.

## 검증 방법

### API 서버
1. `uv run uvicorn api_server:app --host 0.0.0.0 --port 8000`
2. curl로 multipart 파일 업로드:
   ```bash
   curl -X POST http://localhost:8000/review \
     -F "script=@sample/inputs/scripts_.json" \
     -F "summary=@sample/inputs/summary_.json" \
     -F "prompt=@sample/inputs/prompts_.st" \
     -F "rubric=@sample/inputs/score_.json" \
     -F "template_schema=@sample/inputs/template_schema_.json" \
     -o review_result.json
   ```
3. `review_result.json`에 모든 루브릭 항목 점수 + 이유 + 개선안 포함 확인

### CLI (테스트)
1. `uv run python run_review.py --config config.yaml`
2. `sample/outputs/review_result.json` 생성 확인

### LangGraph Studio
1. `uv run langgraph dev` → Studio UI에서 그래프 흐름 확인
