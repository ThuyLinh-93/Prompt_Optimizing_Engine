"""settings.py 환경변수 오버라이드 + 로깅 설정 테스트."""

import logging
import os
import tempfile

import pytest


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """테스트 간 환경변수 오염 방지."""
    override_keys = [
        "LANGSMITH_ENABLED",
        "LLM_PROVIDER",
        "VLLM_BASE_URL",
        "VLLM_MODEL",
        "OPENAI_MODEL",
        "LLM_TEMPERATURE",
        "LLM_MAX_TOKENS",
        "SERVER_HOST",
        "SERVER_PORT",
        "FILE_SCRIPT",
        "FILE_SUMMARY",
        "FILE_PROMPT",
        "FILE_RUBRIC",
        "CONTEXT_MAX_INPUT_TOKENS",
        "CONTEXT_STRATEGY",
        "CONTEXT_CHUNK_SIZE",
        "LOG_FILE",
        "LOG_LEVEL",
    ]
    for key in override_keys:
        monkeypatch.delenv(key, raising=False)


def _make_config():
    """config.yaml 기본 구조를 dict로 반환."""
    return {
        "llm": {
            "provider": "vllm",
            "vllm": {"base_url": "http://localhost:8080/v1", "model": "gemma"},
            "openai": {"model": "gpt-4o"},
            "temperature": 0.3,
            "max_tokens": 4096,
        },
        "langsmith": {"enabled": True, "project": "test"},
        "server": {"host": "0.0.0.0", "port": 8080},
        "files": {
            "script": "script.json",
            "summary": "summary.json",
            "prompt": "prompt.txt",
            "rubric": "rubric.md",
        },
        "context": {"max_input_tokens": 32000, "strategy": "auto", "chunk_size": 2000},
    }


class TestApplyEnvOverrides:
    """apply_env_overrides()가 환경변수 값을 config에 반영하는지 검증."""

    def test_no_override_keeps_original(self, monkeypatch):
        from settings import apply_env_overrides

        config = _make_config()
        result = apply_env_overrides(config)
        assert result["llm"]["provider"] == "vllm"
        assert result["langsmith"]["enabled"] is True

    def test_llm_provider_override(self, monkeypatch):
        monkeypatch.setenv("LLM_PROVIDER", "openai")
        # settings는 모듈 레벨 싱글턴이므로 재생성
        from settings import Settings

        monkeypatch.setattr("settings.settings", Settings())
        from settings import apply_env_overrides

        config = _make_config()
        result = apply_env_overrides(config)
        assert result["llm"]["provider"] == "openai"

    def test_langsmith_enabled_override(self, monkeypatch):
        monkeypatch.setenv("LANGSMITH_ENABLED", "false")
        from settings import Settings

        monkeypatch.setattr("settings.settings", Settings())
        from settings import apply_env_overrides

        config = _make_config()
        result = apply_env_overrides(config)
        assert result["langsmith"]["enabled"] is False

    def test_temperature_override(self, monkeypatch):
        monkeypatch.setenv("LLM_TEMPERATURE", "0.9")
        from settings import Settings

        monkeypatch.setattr("settings.settings", Settings())
        from settings import apply_env_overrides

        config = _make_config()
        result = apply_env_overrides(config)
        assert result["llm"]["temperature"] == 0.9

    def test_server_port_override(self, monkeypatch):
        monkeypatch.setenv("SERVER_PORT", "9090")
        from settings import Settings

        monkeypatch.setattr("settings.settings", Settings())
        from settings import apply_env_overrides

        config = _make_config()
        result = apply_env_overrides(config)
        assert result["server"]["port"] == 9090

    def test_file_override(self, monkeypatch):
        monkeypatch.setenv("FILE_SCRIPT", "custom_script.json")
        from settings import Settings

        monkeypatch.setattr("settings.settings", Settings())
        from settings import apply_env_overrides

        config = _make_config()
        result = apply_env_overrides(config)
        assert result["files"]["script"] == "custom_script.json"
        # 나머지는 원본 유지
        assert result["files"]["summary"] == "summary.json"

    def test_context_override(self, monkeypatch):
        monkeypatch.setenv("CONTEXT_MAX_INPUT_TOKENS", "64000")
        monkeypatch.setenv("CONTEXT_STRATEGY", "chunked")
        from settings import Settings

        monkeypatch.setattr("settings.settings", Settings())
        from settings import apply_env_overrides

        config = _make_config()
        result = apply_env_overrides(config)
        assert result["context"]["max_input_tokens"] == 64000
        assert result["context"]["strategy"] == "chunked"


class TestSetupLogging:
    """setup_logging()이 콘솔/파일 핸들러를 올바르게 설정하는지 검증."""

    def test_console_only(self, monkeypatch):
        monkeypatch.delenv("LOG_FILE", raising=False)
        from settings import Settings

        monkeypatch.setattr("settings.settings", Settings())

        # root logger 핸들러 초기화
        root = logging.getLogger()
        root.handlers.clear()

        from settings import setup_logging

        setup_logging()

        stream_handlers = [h for h in root.handlers if isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)]
        assert len(stream_handlers) >= 1

    def test_file_handler_created(self, monkeypatch):
        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = os.path.join(tmpdir, "sub", "test.log")
            monkeypatch.setenv("LOG_FILE", log_path)
            from settings import Settings

            monkeypatch.setattr("settings.settings", Settings())

            root = logging.getLogger()
            root.handlers.clear()

            from settings import setup_logging

            setup_logging()

            file_handlers = [h for h in root.handlers if isinstance(h, logging.FileHandler)]
            assert len(file_handlers) >= 1
            assert os.path.exists(log_path)
