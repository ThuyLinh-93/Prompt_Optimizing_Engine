from langgraph.graph import END, StateGraph

from agents.optimizer.nodes import optimize
from graph.state import OptimizeState


def build_optimize_graph() -> StateGraph:
    """optimizer 에이전트 LangGraph 그래프를 조립한다."""
    graph = StateGraph(OptimizeState)

    graph.add_node("optimize", optimize)

    graph.set_entry_point("optimize")
    graph.add_edge("optimize", END)

    return graph.compile()


# LangGraph Studio용 모듈 레벨 변수
optimize_graph = build_optimize_graph()
