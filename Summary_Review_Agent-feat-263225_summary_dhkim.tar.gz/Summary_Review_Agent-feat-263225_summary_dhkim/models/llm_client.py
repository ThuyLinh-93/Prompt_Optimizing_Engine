import os

from langchain_openai import ChatOpenAI


def get_llm(config: dict) -> ChatOpenAI:
    """config.yaml의 llm 설정에 따라 LLM 클라이언트를 생성한다."""
    llm_config = config["llm"]
    provider = llm_config["provider"]
    temperature = llm_config.get("temperature", 0.3)
    max_tokens = llm_config.get("max_tokens", 4096)

    if provider == "vllm":
        vllm = llm_config["vllm"]
        return ChatOpenAI(
            base_url=vllm["base_url"],
            model=vllm["model"],
            temperature=temperature,
            max_tokens=max_tokens,
            api_key="EMPTY",
        )
    elif provider == "openai":
        openai_config = llm_config["openai"]
        return ChatOpenAI(
            model=openai_config["model"],
            temperature=temperature,
            max_tokens=max_tokens,
            api_key=os.getenv("OPENAI_API_KEY"),
        )
    else:
        raise ValueError(f"Unknown LLM provider: {provider}")


def setup_langsmith(config: dict) -> None:
    """LangSmith 트레이싱을 설정한다."""
    from settings import settings

    langsmith_config = config.get("langsmith", {})
    if langsmith_config.get("enabled", False):
        os.environ["LANGCHAIN_TRACING_V2"] = "true"
        os.environ["LANGCHAIN_PROJECT"] = langsmith_config.get(
            "project", "prompt-optimizer"
        )
        if settings.langsmith_api_key:
            os.environ["LANGCHAIN_API_KEY"] = settings.langsmith_api_key
    else:
        os.environ["LANGCHAIN_TRACING_V2"] = "false"
