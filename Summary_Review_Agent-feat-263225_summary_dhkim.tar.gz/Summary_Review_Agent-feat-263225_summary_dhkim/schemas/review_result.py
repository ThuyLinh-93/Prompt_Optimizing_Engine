from pydantic import BaseModel


class CriterionResult(BaseModel):
    name: str
    score: float
    max_score: float
    reason: str
    improvements: list[str]


class ReviewResult(BaseModel):
    total_score: float
    max_total_score: float
    criteria: list[CriterionResult]
    overall_feedback: str
    top_improvements: list[str]
    metadata: dict
