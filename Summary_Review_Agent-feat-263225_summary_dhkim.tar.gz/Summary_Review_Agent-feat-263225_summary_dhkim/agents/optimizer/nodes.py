import json
import logging
from pathlib import Path

from langchain_core.messages import HumanMessage
from langchain_core.runnables import RunnableConfig

from graph.state import OptimizeState

logger = logging.getLogger(__name__)


def _format_criteria_details(review_result: dict) -> str:
    """review_result의 criteria를 프롬프트에 주입할 텍스트로 변환한다."""
    lines = []
    for criterion in review_result.get("criteria", []):
        score = criterion.get("score", 0)
        max_score = criterion.get("max_score", 0)
        lines.append(f"#### {criterion['name']} ({score}/{max_score})")
        lines.append(f"- 감점 사유: {criterion.get('reason', '')}")
        improvements = criterion.get("improvements", [])
        if improvements:
            lines.append("- 개선안:")
            for imp in improvements:
                lines.append(f"  - {imp}")
        lines.append("")
    return "\n".join(lines)


def _format_top_improvements(review_result: dict) -> str:
    """top_improvements를 번호 목록으로 변환한다."""
    items = review_result.get("top_improvements", [])
    return "\n".join(f"{i + 1}. {item}" for i, item in enumerate(items))


def _build_optimize_prompt(prompt: str, review_result: dict) -> str:
    """optimizer 시스템 프롬프트를 조립한다."""
    prompts_dir = Path(__file__).parent / "prompts"
    template = (prompts_dir / "optimizer_system.md").read_text(encoding="utf-8")
    return template.format(
        prompt=prompt,
        overall_feedback=review_result.get("overall_feedback", ""),
        top_improvements=_format_top_improvements(review_result),
        criteria_details=_format_criteria_details(review_result),
    )


def optimize(state: OptimizeState, config: RunnableConfig) -> dict:
    """리뷰 결과를 기반으로 프롬프트를 개선한다."""
    if state.get("error"):
        return {}

    llm = config["configurable"]["llm"]

    # review_result가 문자열이면 파싱
    review_result = state["review_result"]
    if isinstance(review_result, str):
        try:
            review_result = json.loads(review_result)
        except json.JSONDecodeError as e:
            return {"error": f"review_result JSON 파싱 실패: {e}"}

    content = _build_optimize_prompt(state["prompt"], review_result)
    response = llm.invoke([HumanMessage(content=content)])

    optimized = response.content.strip()

    logger.debug("개선된 프롬프트:\n%s", optimized)

    # CLI 모드에서만 디스크에 저장
    save_to_disk = config["configurable"].get("save_to_disk", True)
    if save_to_disk:
        output_dir = Path(config["configurable"]["paths"]["output_dir"])
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "optimized_prompts.st").write_text(optimized, encoding="utf-8")

    return {"optimized_prompt": optimized}
