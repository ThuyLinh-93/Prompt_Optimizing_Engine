import re


def estimate_tokens(text: str) -> int:
    """글자 수 기반 토큰 추정. 한글 1자 ≈ 2토큰, 영문 1단어 ≈ 1.3토큰."""
    korean_chars = len(re.findall(r"[가-힣]", text))
    non_korean = re.sub(r"[가-힣]", "", text)
    english_words = len(non_korean.split())
    return int(korean_chars * 2 + english_words * 1.3)


def decide_strategy(
    script: str,
    summary: str,
    prompt: str,
    rubric: str,
    config: dict,
) -> str:
    """컨텍스트 전략을 결정한다. auto 모드에서는 토큰 한도에 따라 자동 결정."""
    context_config = config.get("context", {})
    strategy = context_config.get("strategy", "auto")

    if strategy != "auto":
        return strategy

    max_tokens = context_config.get("max_input_tokens", 6000)
    total = estimate_tokens(script + summary + prompt + rubric)

    if total <= max_tokens:
        return "full"

    without_script = estimate_tokens(summary + prompt + rubric)
    if without_script <= max_tokens:
        return "no_script"

    return "chunked"


def chunk_script(script: str, config: dict) -> list[str]:
    """script를 설정된 chunk_size 토큰 단위로 분할한다."""
    chunk_size = config.get("context", {}).get("chunk_size", 2000)
    paragraphs = script.split("\n\n")

    chunks = []
    current_chunk = []
    current_tokens = 0

    for para in paragraphs:
        para_tokens = estimate_tokens(para)
        if current_tokens + para_tokens > chunk_size and current_chunk:
            chunks.append("\n\n".join(current_chunk))
            current_chunk = [para]
            current_tokens = para_tokens
        else:
            current_chunk.append(para)
            current_tokens += para_tokens

    if current_chunk:
        chunks.append("\n\n".join(current_chunk))

    return chunks
