from langgraph.graph import END, StateGraph

from agents.review.nodes import (
    aggregate,
    check_context,
    chunked_review,
    load_inputs,
    parse_output,
    review,
    route_after_context,
)
from graph.state import ReviewState


def build_review_graph() -> StateGraph:
    """리뷰 에이전트 LangGraph 그래프를 조립한다."""
    graph = StateGraph(ReviewState)

    # 노드 등록
    graph.add_node("load_inputs", load_inputs)
    graph.add_node("check_context", check_context)
    graph.add_node("review", review)
    graph.add_node("chunked_review", chunked_review)
    graph.add_node("aggregate", aggregate)
    graph.add_node("parse_output", parse_output)

    # 엣지 연결
    graph.set_entry_point("load_inputs")
    graph.add_edge("load_inputs", "check_context")

    # 조건부 엣지: 컨텍스트 전략에 따라 분기
    graph.add_conditional_edges(
        "check_context",
        route_after_context,
        {
            "review": "review",
            "chunked_review": "chunked_review",
            "parse_output": "parse_output",
        },
    )

    graph.add_edge("review", "parse_output")
    graph.add_edge("chunked_review", "aggregate")
    graph.add_edge("aggregate", "parse_output")
    graph.add_edge("parse_output", END)

    return graph.compile()


# LangGraph Studio용 모듈 레벨 변수
graph = build_review_graph()
